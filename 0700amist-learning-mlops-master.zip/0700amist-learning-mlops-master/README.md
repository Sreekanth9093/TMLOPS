# 0700amist-learning-mlops
This repo to hold documentation along with source code buillding and deploying models using MLOPS
